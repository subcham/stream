<?php
$host = $_SERVER['HTTP_HOST'];
echo $host;
?>