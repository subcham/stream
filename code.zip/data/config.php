<?php
$connection = mysqli_connect("localhost", "play", "byh1021997", "play");
?>