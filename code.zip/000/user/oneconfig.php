<?php
$servername = "localhost";
$username = "play";
$password = "byh1021997";
$dbname = "play";
?>