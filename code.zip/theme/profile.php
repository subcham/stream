<?php

include $_SERVER['DOCUMENT_ROOT'] . "/data/config.php";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $username = mysqli_real_escape_string($connection, $_POST['username']);
     $password = password_hash(mysqli_real_escape_string($connection, $_POST['password']), PASSWORD_DEFAULT);
    $id = 1;

    $sql = "UPDATE users SET username='$username', password='$password' WHERE id=$id";
    if (mysqli_query($connection, $sql)) {
        echo "Record updated successfully";
    } else {
        echo "Error updating record: " . mysqli_error($connection);
    }
}

mysqli_close($connection);
?>

<!DOCTYPE html>
<html>
<head>
    <title>Update User</title>
    <script>
        function togglePasswordVisibility() {
            var passwordInput = document.getElementById('password');
            var toggleButton = document.getElementById('togglePassword');
            if (passwordInput.type === 'password') {
                passwordInput.type = 'text';
                toggleButton.textContent = 'Hide';
            } else {
                passwordInput.type = 'password';
                toggleButton.textContent = 'Show';
            }
        }
    </script>
</head>
<body>
    <h2>Update User</h2>
    <form method="post">
        Username: <br><input type="text" name="username" required><br><br>
        Password: <br><input type="password" id="password" name="password" required>
        <button type="button" id="togglePassword" onclick="togglePasswordVisibility()">Show</button><br><br>
        <input type="submit" value="Save">
    </form>
</body>
</html>