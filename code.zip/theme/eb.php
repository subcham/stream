<!-- Page title -->
<div class="page-header">
   <div class="row align-items-center">
      <div class="col-auto">
         <ol class="breadcrumb" aria-label="breadcrumbs">
            <li class="breadcrumb-item"><a href="<?=PROOT?>/dashboard">Dashboard</a></li>
            <li class="breadcrumb-item active" aria-current="page"><a href="javascript:void(0)">Bulk Import</a></li>
         </ol>
         <span style="font-size: 14px; color: red;">Supported sources: Stream, Abyss, Helvid, Direct link</span><br>
         <span style="font-size: 14px; color: blue;">Hướng dẫn Import link Microsoft Stream:<br>Bước 1: <a href="https://<?= htmlspecialchars($_SERVER['HTTP_HOST']) ?>/000/admin/onedrive.php/"> Click truy cập</a> và nhập link Stream, copy link<br>Bước 2: Quay lại trang này và Import </span>
      </div>
   </div>
</div>
<!-- Content here -->
<form method="post" action="" id="linkForm">
    <textarea name="link-list" id="link-list" class="form-control" placeholder="SLCA.mkv | https://short.ink/Q8ZSub1_F" rows="15"></textarea>
    <button type="button" onclick="processLinks()" class="btn btn-primary mt-2">Process Links</button>
</form>
<div id="processed-links" class="mt-3"></div>

<script>
function processLinks() {
    var formData = new FormData(document.getElementById('linkForm'));
    fetch('', { // URL của file PHP xử lý, để trống nếu xử lý trên cùng một file
        method: 'POST',
        body: formData,
    })
    .then(response => response.text())
    .then(data => {
        document.getElementById('processed-links').innerHTML = data;
    });
}
</script>

<?php
if ($_SERVER['REQUEST_METHOD'] == 'POST' && !empty($_POST['link-list'])) {
    include __DIR__ . '/../data/config.php';
    $links = explode("\n", $_POST['link-list']);
    $processedLinks = [];

    foreach ($links as $link) {
        list($title, $main_link) = explode('|', $link);
        $title = trim($title);
        $main_link = trim($main_link);
        if (strpos($main_link, 'helvid') !== false) {
            $type = 'Helvid';
            $slug = 'playhe.php?url='.basename(parse_url($main_link, PHP_URL_PATH));
                } elseif (strpos($main_link, 'short.ink') !== false) {
            $type = 'Abyss';
            $slug = 'playab.php?url='.basename(parse_url($main_link, PHP_URL_PATH));
                } elseif (strpos($main_link, $_SERVER['HTTP_HOST']) !== false) {
            $type = 'Stream';
            $slug = 'live.php?live='.basename(parse_url($main_link, PHP_URL_PATH));
                } else {
            $type = 'Direct';
            $k9 = substr($main_link, 8, 1);
            $slug = "dr".$k9.substr(str_shuffle(str_repeat('ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789', 12)), 0, 12);
                }
        $timestamp = date('Y-m-d H:i:s');

        $checkQuery = "SELECT * FROM links WHERE main_link = '$main_link'";
        $checkResult = mysqli_query($connection, $checkQuery);
        if (mysqli_num_rows($checkResult) == 0) {
            $insertQuery = "INSERT INTO links (acc_id, title, main_link, type, updated_at, created_at, slug) VALUES ('1','$title', '$main_link', '$type', '$timestamp', '$timestamp', '$slug')";
            mysqli_query($connection, $insertQuery);
        }
        $host = $_SERVER['HTTP_HOST'];
        $processedLinks[] = "https://$host/data/$slug";
    }

    foreach ($processedLinks as $plink) {
        echo "<a href='$plink'>$plink</a><br>";
    }
}
?>